@echo off
setlocal EnableExtensions
cd /d "%~dp0"
call PrepPython.bat
if errorlevel 1 goto fail
call BuildExe.bat
if errorlevel 1 goto fail
if exist "netbird_installer_0_82_0_windows_amd64.msi" goto nbok
echo Put netbird_installer_0_82_0_windows_amd64.msi in this folder ^(download from github.com/netbirdio/netbird/releases^), then run again.
goto fail
:nbok
set ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe
if not exist "%ISCC%" set ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe
if not exist "%ISCC%" echo Inno Setup 6 not found. & goto fail
"%ISCC%" ZaiaRemoteSetup.iss
if errorlevel 1 goto fail
echo Done. See Output\ZaiaRemoteSetup.exe
pause
exit /b 0
:fail
echo.
echo BUILD FAILED. Read the messages above.
pause
exit /b 1
