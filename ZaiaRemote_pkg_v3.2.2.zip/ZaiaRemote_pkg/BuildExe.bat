@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"

echo [1] หาโฟลเดอร์ .NET...
set CSC=%windir%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%windir%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if exist "%CSC%" goto havecsc
echo ไม่พบ csc.exe ทั้งสองที่ เครื่องนี้อาจไม่มี .NET Framework 4.0.30319
pause
exit /b 1
:havecsc
echo     ใช้: %CSC%

if exist "Launcher.cs" goto havecs
echo ไม่พบไฟล์ Launcher.cs ในโฟลเดอร์นี้
pause
exit /b 1
:havecs

if exist "zaia.ico" goto haveico
echo ไม่พบไฟล์ zaia.ico ในโฟลเดอร์นี้
pause
exit /b 1
:haveico

echo [2] กำลัง build ZaiaRemote.exe ...
"%CSC%" /nologo /target:winexe /out:ZaiaRemote.exe /win32icon:zaia.ico Launcher.cs
set BUILD_RC=%errorlevel%

if %BUILD_RC% equ 0 goto buildok
echo.
echo BUILD ล้มเหลว errorlevel %BUILD_RC% - ดูข้อความ error ด้านบน
pause
exit /b %BUILD_RC%

:buildok
echo.
echo BUILD สำเร็จ: ZaiaRemote.exe
pause
exit /b 0